<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/wp-load.php' );

/**
 * Adds GarageWidget widget.
 */
 if (! class_exists('GarageWidgetData')) {
	class GarageWidgetData {

		 
		 /**
		 * Callback function of independent garage
		 * 
		**/
		public function independent_garage_form($id = 0)
		{
			?>
			<?php
				global $wpdb;
				$this->table_name = $wpdb->prefix . 'garage_rating';   
				
				$postId = $id; 
				$posts = get_post($postId );				
				$querystr = "SELECT AVG(`rating`) FROM {$this->table_name} WHERE garage_id = %d ";
				$query = $wpdb->prepare( $querystr,  $postId);
				$avg_res = $wpdb->get_var($query);
				
			?>
				<div class="independent-container" style="float:left; width:100%; background:url(http://ecp-autofirst.netsolutions.in/wp-content/themes/autofirstnetwork/bootstrap/images/home-form-back.png) repeat 0 0; margin-bottom:10px; border:10px solid #fff;">
					<div class="independent-title" style="color: #000000;float:left; padding:20px 20px 25px; width:100%; text-align:center; font-size: 18px;font-weight: bold; border-bottom:10px solid #e10f2f;">
					
						<h2 style="color: #e10f2f;float:left; width:100%;font-family: arial; margin:0; font-size:32px; text-transform:uppercase; line-height:24px;"><?php echo $posts->post_title;?></h2>
						is rated
						<input type="number" readonly value="<?php echo round($avg_res);?>" id="independent_rating_list" class="rating" data-readonly data-size="lg"/>
						<?php echo round($avg_res);?> stars out of 5 <br/>
						By <img src="<?php echo TEMPLATE_URL; ?>/bootstrap/images/image021.png">customers
					</div>
				</div>
				
			<?php 
				 
		}

	}
	$obj = new GarageWidgetData();
	$obj->independent_garage_form($_REQUEST['id']);
}
?>

